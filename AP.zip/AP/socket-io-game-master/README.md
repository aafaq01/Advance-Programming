# Socket.io Game Demo

This is me messing around with building a (very) simple multiplayer online game with socket.io. See `BLOG.md` for a bit about what my motivations were and what I learnt about this stuff. Hacker News discussion is [here](https://news.ycombinator.com/item?id=15318530).
 You can check out the game [here](http://socket-blocker.herokuapp.com/)

![Screenshot](./screenshot.png)
